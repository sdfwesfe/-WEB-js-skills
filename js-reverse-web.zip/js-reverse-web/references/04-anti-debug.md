# 04 反调试与对抗

**适用条件：断点调试受到干扰——无限debugger / 打开DevTools后页面异常 / 切窗口数据消失 / 单步走到假分支。**
调试正常 → 不需要读本文档。

优先用最简单的方法，实在不行上传输层替换（终极方案）。

---

## 一、无限 debugger

### 1.1 三种实现识别

```javascript
// 类型一：定时器（最常见）
setInterval(function() { debugger }, 50)

// 类型二：Function 构造器（绕过简单字符串搜索）
setInterval(new Function("debugger"), 50)

// 类型三：toString getter 触发
var a = function() {}
Object.defineProperty(a, 'name', { get: function() { debugger } })
var b = a.name
```

### 1.2 四种绕过（按推荐优先级）

**方法一：Never pause here（最快，30秒搞定）**
```
找到 debugger 语句所在行 → 右键行号 → Never pause here
每个文件单独设置，调试期间永久生效
```

**方法二：停用所有断点**
```
DevTools 右上角 → 点击"停用断点"图标（斜线穿过圆点）
快捷键：Ctrl+F8
注意：自己打的断点也会停用，调试时记得重新开启
```

**方法三：条件断点清除定时器**
```
在 setInterval 调用处右键 → Add conditional breakpoint
条件：(window.clearInterval(arguments[0]), false)
效果：命中时自动清除定时器，且不暂停
```

**方法四：Tampermonkey 注入（根治，@run-at document-start）**
```javascript
// ==UserScript==
// @match https://target.com/*
// @run-at document-start
// ==/UserScript==
;(function() {
    // 过滤包含 debugger 的 setInterval / setTimeout
    const _si = window.setInterval
    window.setInterval = function(fn, d) {
        if (typeof fn === 'function' && fn.toString().includes('debugger')) return 0
        if (typeof fn === 'string' && fn.includes('debugger')) return 0
        return _si.apply(this, arguments)
    }
    const _st = window.setTimeout
    window.setTimeout = function(fn, d) {
        if (typeof fn === 'function' && fn.toString().includes('debugger')) return 0
        return _st.apply(this, arguments)
    }
    // 覆盖 Function 构造器
    const _F = window.Function
    window.Function = function() {
        const args = Array.from(arguments)
        if (String(args[args.length - 1]).includes('debugger')) args[args.length - 1] = ''
        return _F.apply(this, args)
    }
    window.Function.prototype = _F.prototype
})()
```

---

## 二、时间检测

### 2.1 识别

```javascript
// 特征：两个 Date.now() 差值判断
var t1 = Date.now()
// ... 目标代码 ...
var t2 = Date.now()
if (t2 - t1 > 200) {
    // 检测到调试，走假逻辑 / 清空数据 / 报错
}
// 也可能用 performance.now()（精度更高）
```

### 2.2 完整绕过

```javascript
// Console 或 Tampermonkey 注入，时间静止
;(function() {
    const _now = Date.now()

    // 固定 Date.now()
    Date.now = function() { return _now }

    // 固定 new Date()
    const _Date = Date
    window.Date = function() {
        return arguments.length === 0 ? new _Date(_now) : new _Date(...arguments)
    }
    window.Date.now = function() { return _now }
    Object.setPrototypeOf(window.Date, _Date)

    // 固定 performance.now()
    const _perfBase = performance.now()
    Object.defineProperty(performance, 'now', {
        value: function() { return _perfBase },
        writable: true
    })
})()
```

---

## 三、DevTools 检测

### 3.1 窗口尺寸检测

```javascript
// 检测：打开 DevTools 后 outerWidth - innerWidth > 160
setInterval(function() {
    if (window.outerWidth - window.innerWidth > 160) {
        document.body.innerHTML = '检测到调试工具'
    }
}, 1000)
```

**绕过**：将 DevTools 独立为单独窗口（DevTools 右上角三点 → Undock into separate window），此时 inner/outer 尺寸不受影响。

### 3.2 console 对象检测

```javascript
// 利用 getter 在 console 展开对象时触发
var obj = /./
obj.toString = function() { /* 检测逻辑 */ }
console.log('%c', obj)
```

**绕过**：
```javascript
// 覆盖 console.log，过滤掉检测相关调用
const _log = console.log
console.log = function() {
    const args = Array.from(arguments)
    if (args.some(a => a instanceof RegExp)) return  // 过滤 RegExp 检测
    _log.apply(console, arguments)
}
```

---

## 四、焦点/鼠标检测

### 4.1 识别

```javascript
// 切换到 DevTools 时，页面失焦触发
window.addEventListener('blur', function() {
    document.querySelector('#password').value = ''  // 清空输入
})
document.addEventListener('visibilitychange', function() {
    if (document.hidden) { /* 清空数据 */ }
})
```

### 4.2 绕过（在页面加载前注入）

```javascript
// Tampermonkey @run-at document-start
;(function() {
    const _orig = EventTarget.prototype.addEventListener
    EventTarget.prototype.addEventListener = function(type, listener, options) {
        // 过滤 blur / visibilitychange / focus 事件绑定
        if (['blur', 'visibilitychange', 'focus'].includes(type)) {
            console.log('[Anti-debug blocked event]', type)
            return
        }
        return _orig.call(this, type, listener, options)
    }
})()
```

---

## 五、代码完整性校验

### 5.1 识别

```
判断方法：
1. 正常操作一次，记录所有请求参数
2. 在 JS 文件里加一个空格（最小修改）
3. 再次操作，对比请求参数是否变化
   → 有新参数 / 某参数值变化 → 存在完整性校验
   → 参数完全相同 → 无校验
```

### 5.2 绕过原则

**不修改 JS 源文件本身，所有 Hook 代码通过 Console 手动注入或 Tampermonkey 注入。**

```
✅ 正确做法：
- Console 注入 Hook 代码
- Tampermonkey 脚本注入
- Logpoint 代替打 console.log
- 控制台直接调用目标函数

❌ 会触发校验：
- Sources 里直接编辑 JS 文件
- DevTools Overrides 功能替换 JS
- 直接用 mitmproxy 在 JS 里插 console.log
```

---

## 六、传输层替换（终极方案）

客户端反调试过多时，在网络层替换 JS，**完全绕过所有客户端检测**，浏览器收到的已经是处理过的代码。

### 6.1 工作流

```
正常：浏览器 → 服务器 → 原始 JS（含反调试）
替换：浏览器 → mitmproxy → 服务器
                  ↓
             替换 JS 内容（去反调试 + 注入 Hook）
                  ↓
             返回处理后的 JS
```

### 6.2 mitmproxy addon 完整模板

```python
# bypass_antidebug.py
# 启动：mitmproxy -s bypass_antidebug.py -p 8080

import re
from mitmproxy import http

# 配置要处理的 JS 文件关键词
TARGET_KEYWORDS = ['main.chunk.js', 'app.bundle.js', 'login.js']

# 要注入到目标 JS 头部的 Hook 代码
INJECT_CODE = """
;(function(){
  /* mitmproxy injected */
  // 1. 屏蔽 debugger 定时器
  var _si = setInterval;
  setInterval = function(fn, d) {
    if (typeof fn === 'function' && fn.toString().indexOf('debugger') > -1) return 0;
    return _si.apply(this, arguments);
  };
  // 2. 时间静止
  var _t = Date.now();
  Date.now = function(){ return _t; };
  // 3. 屏蔽 blur/visibilitychange
  var _ae = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function(type, fn, opt) {
    if (type === 'blur' || type === 'visibilitychange') return;
    return _ae.call(this, type, fn, opt);
  };
  console.log('[mitmproxy] anti-debug bypass injected');
})();
"""

class AntiDebugBypass:

    def response(self, flow: http.HTTPFlow) -> None:
        url = flow.request.url
        ct = flow.response.headers.get('content-type', '')

        if 'javascript' not in ct and not url.endswith('.js'):
            return
        if not any(kw in url for kw in TARGET_KEYWORDS):
            return

        try:
            body = flow.response.text
        except Exception:
            return

        orig_len = len(body)

        # 移除无限 debugger
        body = re.sub(
            r'setInterval\s*\(\s*(function\s*\(\s*\)\s*\{[^}]*debugger[^}]*\}|new\s+Function\s*\(\s*["\']debugger["\']\s*\))\s*,\s*\d+\s*\)',
            'setInterval(function(){},99999)',
            body
        )
        # 移除时间差检测
        body = re.sub(r'(\w+)\s*-\s*(\w+)\s*>\s*\d+', '0 > 999999', body)
        # 移除窗口尺寸检测
        body = re.sub(r'outerWidth\s*-\s*innerWidth', '0', body)

        # 注入 Hook 代码到文件头部
        body = INJECT_CODE + body

        if len(body) != orig_len:
            print(f'[bypass] Modified: {url}')
            flow.response.text = body

    def inject_hook_at_function(self, body: str,
                                 func_signature: str, hook_code: str) -> str:
        """在指定函数定义处注入 hook 代码"""
        return body.replace(
            func_signature,
            func_signature + '\n' + hook_code
        )

addons = [AntiDebugBypass()]
```

### 6.3 使用步骤

```bash
# 1. 安装
pip install mitmproxy

# 2. 启动代理
mitmproxy -s bypass_antidebug.py -p 8080

# 3. 浏览器设置代理 127.0.0.1:8080

# 4. 安装 mitmproxy HTTPS 证书
#    浏览器访问 http://mitm.it → 下载安装证书

# 5. 访问目标站点
#    mitmproxy 终端会显示被修改的 JS 文件
```
