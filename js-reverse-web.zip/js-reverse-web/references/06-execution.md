# 06 代码执行方案与 Burp autoDecoder 联动

**适用条件：已理解加密逻辑，需要选择执行方式，或需要接入 Burp autoDecoder 实现自动加解密。**

---

## 一、方案选型

```
能提取出密钥和算法？
├── 是 → Python / Node.js 直接复现（最简洁，优先）
│
└── 否
    ├── 逻辑复杂但不依赖浏览器 API → Node.js 补环境（§ 二）
    ├── 依赖 canvas / webgl / 指纹  → jsrpc（§ 三）
    ├── 需要完整页面状态           → Puppeteer（§ 四）
    └── Burp 手工/自动化测试       → autoDecoder（§ 五）← 重点
```

---

## 二、Node.js 补环境

### 2.1 一次性补全模板

```javascript
// env.js - 在执行目标 JS 前 require 此文件

global.window   = global
global.self     = global

global.location = {
    href: 'https://target.com/login', hostname: 'target.com',
    host: 'target.com', protocol: 'https:', pathname: '/login',
    search: '', hash: '', origin: 'https://target.com'
}

global.navigator = {
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    language: 'zh-CN', languages: ['zh-CN', 'zh', 'en'],
    platform: 'Win32', hardwareConcurrency: 8,
    maxTouchPoints: 0, cookieEnabled: true, onLine: true,
    vendor: 'Google Inc.', appName: 'Netscape', product: 'Gecko'
}

global.screen = {
    width: 1920, height: 1080,
    availWidth: 1920, availHeight: 1040,
    colorDepth: 24, pixelDepth: 24
}

global.document = {
    cookie: '', title: '', domain: 'target.com',
    readyState: 'complete', referrer: '',
    createElement: (tag) => {
        const el = { style: {}, setAttribute: () => {}, getAttribute: () => null }
        if (tag === 'canvas') {
            el.getContext = (type) => {
                if (type === '2d') return {
                    fillText: () => {}, measureText: () => ({ width: 100 }),
                    fillRect: () => {}, clearRect: () => {},
                    getImageData: () => ({ data: new Uint8ClampedArray(4) }),
                    save: () => {}, restore: () => {}, scale: () => {},
                    font: '', fillStyle: '', textBaseline: '', textAlign: ''
                }
                if (type === 'webgl' || type === 'experimental-webgl') return {
                    getParameter: (p) => ({
                        37445: 'Google Inc.', 37446: 'ANGLE (Intel HD Graphics)',
                        7936: 'WebKit WebGL', 7937: 'WebKit'
                    }[p] || ''),
                    getExtension: (n) => n === 'WEBGL_debug_renderer_info'
                        ? { UNMASKED_VENDOR_WEBGL: 37445, UNMASKED_RENDERER_WEBGL: 37446 }
                        : null,
                    getSupportedExtensions: () => []
                }
                return null
            }
            el.toDataURL = () => 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQI12NgAAIABQAABjE+ibYAAAAASUVORK5CYII='
            el.width = 300; el.height = 150
        }
        return el
    },
    getElementById: () => null, querySelector: () => null,
    querySelectorAll: () => [], getElementsByTagName: () => [],
    body: { appendChild: () => {}, style: {} },
    head: { appendChild: () => {} },
    addEventListener: () => {}, removeEventListener: () => {}
}

const _store = {}
const makeStorage = () => ({
    getItem: k => _store[k] ?? null,
    setItem: (k, v) => { _store[k] = String(v) },
    removeItem: k => { delete _store[k] },
    clear: () => Object.keys(_store).forEach(k => delete _store[k]),
    get length() { return Object.keys(_store).length },
    key: i => Object.keys(_store)[i] ?? null
})
global.localStorage  = makeStorage()
global.sessionStorage = makeStorage()

global.atob = str => Buffer.from(str, 'base64').toString('binary')
global.btoa = str => Buffer.from(str, 'binary').toString('base64')

const { TextEncoder, TextDecoder } = require('util')
global.TextEncoder = TextEncoder
global.TextDecoder = TextDecoder

const { webcrypto } = require('crypto')
global.crypto = webcrypto

global.XMLHttpRequest = function() {
    return { open: () => {}, send: () => {}, setRequestHeader: () => {},
             addEventListener: () => {}, readyState: 4, status: 200 }
}
global.fetch = () => Promise.resolve({ json: () => ({}), text: () => '' })
global.requestAnimationFrame = fn => setTimeout(fn, 16)
global.performance = global.performance || { now: Date.now }
```

### 2.2 常见报错速查

| 报错 | 解决 |
|------|------|
| `window is not defined` | `global.window = global` |
| `document is not defined` | 补充 document mock |
| `btoa is not defined` | 补充 atob/btoa |
| `crypto.subtle is not defined` | `const { webcrypto } = require('crypto'); global.crypto = webcrypto` |
| `canvas.getContext is not a function` | 补充 canvas mock 的 getContext |
| `TextEncoder is not defined` | `const { TextEncoder } = require('util'); global.TextEncoder = TextEncoder` |
| `performance is not defined` | `global.performance = { now: Date.now }` |
| `localStorage is not defined` | 补充 localStorage mock |

---

## 三、jsrpc 方案

### 3.1 架构

```
Python 脚本
  └─ HTTP GET localhost:12080/go?group=G&action=encrypt&param=data
       └─ jsrpc 服务（Node.js）
            └─ WebSocket → 目标网页浏览器
                 └─ 调用真实加密函数 → 返回结果
```

### 3.2 服务端搭建

```bash
git clone https://github.com/jxhczhl/JsRpc.git
cd JsRpc && npm install && node server.js
# 默认监听 12080 端口
```

### 3.3 客户端注入（注入时机：页面加载完 + 目标函数已就绪）

```javascript
// Tampermonkey 自动注入（@run-at document-idle）
var script = document.createElement('script')
script.src = 'http://localhost:12080/jrpc.js'
script.onload = function() {
    var client = new HackerLocalRoutingClient(
        "ws://localhost:12080/ws?group=MyGroup&clientId=chrome_1"
    )

    // 注册单个加密函数
    client.regAction("encrypt", function(resolve, param) {
        resolve(window.encryptFunc(param))
    })

    // 注册需要 JSON 参数的函数
    client.regAction("aesEncrypt", function(resolve, param) {
        var args = JSON.parse(param)  // '{"data":"xxx","key":"yyy"}'
        var result = CryptoJS.AES.encrypt(
            CryptoJS.enc.Utf8.parse(args.data),
            CryptoJS.enc.Utf8.parse(args.key),
            { mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7 }
        ).toString()
        resolve(result)
    })

    // 注册异步函数（指纹生成）
    client.regAction("getFingerprint", function(resolve) {
        FingerprintJS.load().then(fp => fp.get()).then(r => resolve(r.visitorId))
    })

    console.log('[jsrpc] ready')
}
document.head.appendChild(script)
```

### 3.4 Python 调用

```python
import requests, json, time

JSRPC_BASE = "http://localhost:12080/go"
GROUP = "MyGroup"

def jsrpc_call(action: str, param=None, retries: int = 3) -> str:
    if param is None: param = ""
    if isinstance(param, dict): param = json.dumps(param)

    for i in range(retries):
        try:
            resp = requests.get(JSRPC_BASE, params={
                "group": GROUP, "action": action, "param": str(param)
            }, timeout=10)
            result = resp.json()
            if result.get("status") == "ok":
                return result["data"]
            raise Exception(f"jsrpc error: {result}")
        except requests.exceptions.ConnectionError:
            print(f"[jsrpc] 连接失败，浏览器已打开目标页面？({i+1}/{retries})")
            time.sleep(2)
        except requests.exceptions.Timeout:
            print(f"[jsrpc] 超时 ({i+1}/{retries})")
    raise Exception("jsrpc 调用失败")

# 使用示例
enc_password  = jsrpc_call("encrypt", "yourPassword")
fingerprint   = jsrpc_call("getFingerprint")
aes_result    = jsrpc_call("aesEncrypt", {"data": "plaintext", "key": "key1234567890123"})
```

---

## 四、Puppeteer 方案

```javascript
const puppeteer = require('puppeteer')

async function main() {
    const browser = await puppeteer.launch({
        headless: false,
        args: ['--disable-blink-features=AutomationControlled', '--no-sandbox']
    })
    const page = await browser.newPage()

    // 绕过 webdriver 检测
    await page.evaluateOnNewDocument(() => {
        Object.defineProperty(navigator, 'webdriver', { get: () => false })
        window.chrome = { runtime: {} }
    })

    // 屏蔽无用资源，加快速度
    await page.setRequestInterception(true)
    page.on('request', req => {
        if (['image', 'font', 'media', 'stylesheet'].includes(req.resourceType()))
            req.abort()
        else req.continue()
    })

    await page.goto('https://target.com/login', { waitUntil: 'networkidle2' })

    // 在页面上下文中调用加密函数（复用 page，避免重复加载）
    const encrypted = await page.evaluate((plaintext) => {
        return window.encryptFunc(plaintext)
    }, 'yourPassword')

    console.log('encrypted:', encrypted)
    await browser.close()
}
```

---

## 五、Burp autoDecoder 完整联动

autoDecoder 是 Burp 插件，通过 Flask 接口实现**自动加解密**：
- Burp 拦截请求 → 把密文发给 Flask 解密 → Burp 扩展选项卡显示明文
- 在 Repeater/Intruder 中修改明文 → Flask 加密 → Burp 发出密文请求

### 5.1 autoDecoder 接口规范（必读）

**接口必须遵守以下规范，否则会出现乱码、解密失败等问题：**

```
autoDecoder 向你的 Flask 接口 POST 以下参数：

  dataBody        → 请求体（必需）
                    使用 body = request.form.get('dataBody') 获取

  dataHeaders     → 完整请求头字符串（可选，勾选"对请求头处理"时传入）
                    使用 headers = request.form.get('dataHeaders') 获取
                    格式：POST /path HTTP/1.1\r\nHost: ...\r\n...

  requestorresponse → 标识请求包还是响应包（可选）
                    值为 'request' 或 'response'
                    使用 reqresp = request.form.get('requestorresponse') 获取

Flask 接口返回值格式（二选一）：

  ① 不处理请求头：直接返回处理后的 body 字符串
     return encrypted_body

  ② 处理请求头：返回 headers + "\r\n\r\n\r\n\r\n" + body
     return headers + "\r\n\r\n\r\n\r\n" + body
     # 4个\r\n是固定分隔符，不可更改！
```

**关键注意事项（来自官方 FAQ）**：
```
1. 一定要对 body 做 .strip('\n') 处理，否则会多换行
2. 明文关键字 与 密文关键字 不可重合，重合会导致混乱
3. 修改任何配置后必须点保存，否则不生效
4. 请求包/响应包用不同加密算法时，用 requestorresponse 参数区分
5. 高并发会报错，建议 Intruder 线程设为 1-5
6. Proxy 模块不会自动解密（预期行为），只在 autoDecoder 扩展选项卡查看
7. 二进制请求体需要在 Burp User options 中勾选
   Mac: Use the platform default(UTF-8)
   Windows: Display as raw bytes
```

### 5.2 基础 Flask 接口模板

**适合：算法简单、请求/响应用同一套加解密**

```python
# autodecoder_server.py
# -*- coding: utf-8 -*-
from flask import Flask, request
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import base64, hashlib, time

app = Flask(__name__)

# ── 根据逆向结果填写 ──────────────────────────────────
AES_KEY = "-imagic-password"     # 从 JS 断点中提取的 key
AES_MODE = AES.MODE_ECB          # 从 JS 中确认的模式
SIGN_SALT = "hardcoded_salt"     # 从 JS 中提取的盐值

def aes_encrypt(plaintext: str) -> str:
    cipher = AES.new(AES_KEY.encode(), AES_MODE)
    ct = cipher.encrypt(pad(plaintext.encode(), 16))
    return base64.b64encode(ct).decode()

def aes_decrypt(ciphertext: str) -> str:
    cipher = AES.new(AES_KEY.encode(), AES_MODE)
    pt = unpad(cipher.decrypt(base64.b64decode(ciphertext)), 16)
    return pt.decode()

@app.route('/encode', methods=['POST'])
def encode():
    """autoDecoder 加密接口（Burp 发明文 → 返回密文）"""
    body = request.form.get('dataBody', '').strip('\n')
    headers = request.form.get('dataHeaders')

    try:
        encrypted = aes_encrypt(body)
    except Exception as e:
        return f"ENCODE_ERROR: {e}"  # 报错回显，方便调试

    if headers is not None:
        # 勾选了"对请求头处理"时，返回 headers + 分隔符 + body
        return headers + "\r\n\r\n\r\n\r\n" + encrypted
    return encrypted

@app.route('/decode', methods=['POST'])
def decode():
    """autoDecoder 解密接口（Burp 发密文 → 返回明文）"""
    body = request.form.get('dataBody', '').strip('\n')
    headers = request.form.get('dataHeaders')

    try:
        decrypted = aes_decrypt(body)
    except Exception as e:
        return f"DECODE_ERROR: {e}"  # 报错回显

    if headers is not None:
        return headers + "\r\n\r\n\r\n\r\n" + decrypted
    return decrypted

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8888, debug=False)
```

### 5.3 进阶模板：请求/响应不同加密算法

**适合：请求用 AES 加密，响应用另一种格式返回**

```python
@app.route('/encode', methods=['POST'])
def encode():
    body    = request.form.get('dataBody', '').strip('\n')
    headers = request.form.get('dataHeaders')
    reqresp = request.form.get('requestorresponse', 'request')

    try:
        if reqresp == 'request':
            result = aes_encrypt(body)       # 请求包加密
        else:
            result = aes_encrypt_resp(body)  # 响应包加密（不同算法）
    except Exception as e:
        return f"ENCODE_ERROR[{reqresp}]: {e}"

    if headers is not None:
        return headers + "\r\n\r\n\r\n\r\n" + result
    return result

@app.route('/decode', methods=['POST'])
def decode():
    body    = request.form.get('dataBody', '').strip('\n')
    headers = request.form.get('dataHeaders')
    reqresp = request.form.get('requestorresponse', 'request')

    try:
        if reqresp == 'request':
            result = aes_decrypt(body)
        else:
            result = aes_decrypt_resp(body)
    except Exception as e:
        return f"DECODE_ERROR[{reqresp}]: {e}"

    if headers is not None:
        return headers + "\r\n\r\n\r\n\r\n" + result
    return result
```

### 5.4 完整模板：sign + 时间戳 + AES 多参数场景

**适合：JSON 格式请求体，多个字段加密，含 sign 签名**

```python
import json, time, hashlib

@app.route('/encode', methods=['POST'])
def encode():
    """
    处理 JSON 格式请求体：
    输入：{"mobile":"13800138000","password":"明文密码"}
    输出：{"mobile":"13800138000","password":"AES密文","sign":"MD5签名","timestamp":1234567890}
    """
    body    = request.form.get('dataBody', '').strip('\n')
    headers = request.form.get('dataHeaders')

    try:
        params = json.loads(body)

        ts = int(time.time() * 1000)

        # 加密密码（带时间戳前缀）
        if 'password' in params:
            params['password'] = aes_encrypt(str(ts) + params['password'])

        # 加密其他敏感字段
        if 'cardNo' in params:
            params['cardNo'] = aes_encrypt(params['cardNo'])

        # 加时间戳
        params['timestamp'] = ts

        # 计算 sign（最后算，依赖其他参数值）
        sign_params = {k: v for k, v in params.items() if k != 'sign'}
        sorted_str = '&'.join(f"{k}={v}" for k, v in sorted(sign_params.items()))
        params['sign'] = hashlib.md5(
            (sorted_str + SIGN_SALT).encode()
        ).hexdigest()

        result = json.dumps(params, ensure_ascii=False, separators=(',', ':'))
    except Exception as e:
        return f"ENCODE_ERROR: {e}"

    if headers is not None:
        return headers + "\r\n\r\n\r\n\r\n" + result
    return result

@app.route('/decode', methods=['POST'])
def decode():
    """
    解密响应：
    输入：{"code":0,"data":"AES密文"}
    输出：{"code":0,"data":{"user":"xxx",...}}
    """
    body    = request.form.get('dataBody', '').strip('\n')
    headers = request.form.get('dataHeaders')

    try:
        resp = json.loads(body)
        if 'data' in resp and isinstance(resp['data'], str):
            try:
                resp['data'] = json.loads(aes_decrypt(resp['data']))
            except Exception:
                pass  # 有些 data 字段本来就不是加密的
        result = json.dumps(resp, ensure_ascii=False, indent=2)
    except Exception as e:
        # 非 JSON 格式，尝试直接解密
        try:
            result = aes_decrypt(body)
        except Exception:
            return f"DECODE_ERROR: {e}"

    if headers is not None:
        return headers + "\r\n\r\n\r\n\r\n" + result
    return result
```

### 5.5 全加密 body（整个 body 是密文 blob）

```python
@app.route('/encode', methods=['POST'])
def encode():
    """整个 body 就是一个明文，加密后发出"""
    body    = request.form.get('dataBody', '').strip('\n')
    headers = request.form.get('dataHeaders')
    try:
        result = aes_encrypt(body)
    except Exception as e:
        return f"ENCODE_ERROR: {e}"
    if headers is not None:
        return headers + "\r\n\r\n\r\n\r\n" + result
    return result

@app.route('/decode', methods=['POST'])
def decode():
    """整个 body 就是一个密文，解密后显示"""
    body    = request.form.get('dataBody', '').strip('\n')
    headers = request.form.get('dataHeaders')
    try:
        result = aes_decrypt(body)
    except Exception as e:
        return f"DECODE_ERROR: {e}"
    if headers is not None:
        return headers + "\r\n\r\n\r\n\r\n" + result
    return result
```

### 5.6 正则模式（只处理特定字段）

autoDecoder 支持正则提取，只对匹配到的字段内容加解密：

```python
# 配合 autoDecoder 正则模式使用
# 在 autoDecoder 界面设置正则：password=([^&\n]+)
# autoDecoder 提取 password 字段的值传给接口，接口只处理这个值

@app.route('/encode', methods=['POST'])
def encode():
    """正则模式下，body 就是提取出来的单个字段值"""
    body = request.form.get('dataBody', '').strip('\n')
    try:
        return aes_encrypt(body)  # 直接加密，不用解析 JSON
    except Exception as e:
        return f"ENCODE_ERROR: {e}"

@app.route('/decode', methods=['POST'])
def decode():
    body = request.form.get('dataBody', '').strip('\n')
    try:
        return aes_decrypt(body)
    except Exception as e:
        return f"DECODE_ERROR: {e}"
```

### 5.7 SM4 / SM2 场景

```python
from gmssl.sm4 import CryptSM4, SM4_ENCRYPT, SM4_DECRYPT
import base64

SM4_KEY = "your16bytesm4key"

def sm4_ecb_enc(plaintext: str) -> str:
    crypt = CryptSM4()
    crypt.set_key(SM4_KEY.encode(), SM4_ENCRYPT)
    data = plaintext.encode()
    pad_len = 16 - len(data) % 16
    data += bytes([pad_len] * pad_len)
    return base64.b64encode(crypt.crypt_ecb(data)).decode()

def sm4_ecb_dec(ciphertext: str) -> str:
    crypt = CryptSM4()
    crypt.set_key(SM4_KEY.encode(), SM4_DECRYPT)
    data = crypt.crypt_ecb(base64.b64decode(ciphertext))
    pad_len = data[-1]
    return data[:-pad_len].decode()

# 在 encode/decode 路由中替换 aes_encrypt/aes_decrypt 即可
```

### 5.8 autoDecoder 配置步骤

```
1. Burp → Extensions → 加载 autoDecoder.jar

2. autoDecoder 选项卡配置：
   域名：target.com（只有该域名的请求才会被处理）
   接口地址：http://127.0.0.1:8888/encode（加密接口）
             http://127.0.0.1:8888/decode（解密接口）
   明文关键字：{ 或 " （JSON 明文的特征字符）
   密文关键字：（密文的特征，防止二次加密）

3. 勾选项：
   ☑ 接口加解密（使用 Flask 接口）
   ☐ 自带加解密（只用于简单 AES/DES，不推荐复杂场景）
   ☑ 对请求头处理（需要修改 header 中的签名字段时才勾选）

4. 点保存配置（必须！修改任何配置都要保存）

5. 启动 Flask 服务：
   python autodecoder_server.py

6. 接口调试（autoDecoder 内置调试面板）：
   在"接口调试"模块粘贴一个正常的密文请求包
   点击解密 → 查看是否正常返回明文
   失败时在 Extensions 页面或终端查看报错信息

7. 在 Repeater 中使用：
   切到 autoDecoder 选项卡 → 可以看到解密后的明文
   直接在明文中修改参数 → 点发送 → 自动加密发出
```

### 5.9 与 sqlmap 联动（加密数据包注入测试）

```bash
# 方法一：用 -r 加载请求文件（请求文件里是明文，autoDecoder 自动加密）
sqlmap -r request.txt --level 3 --risk 2

# 方法二：自定义 tamper 脚本（在 sqlmap payload 发出前加密）
# tamper/encrypt_payload.py
from lib.core.enums import PRIORITY
import requests

__priority__ = PRIORITY.LOWEST

def tamper(payload, **kwargs):
    """调用 Flask 接口加密 sqlmap 的 payload"""
    resp = requests.post('http://127.0.0.1:8888/encode',
                         data={'dataBody': payload})
    return resp.text.strip()

# 使用：
sqlmap -r request.txt --tamper=encrypt_payload --level 3
```

### 5.10 常见问题排查

```
问题：autoDecoder 选项卡显示解密错误
→ 进 Burp Logger / Logger++ 查看实际发出的数据包
→ 注意：Repeater 内的数据包已被 autoDecoder 处理，要看 Logger 里的实际包

问题：调试模块正常，Repeater 里不正常
→ 原因：调试模块换行是 \n，Repeater 里是 \r\n
→ 解决：在 Flask 代码中加 body.replace('\r\n', '\n')

问题：不出现 autoDecoder 选项卡
→ 检查域名配置是否正确填写，是否已点保存

问题：响应包解密失败但请求包正常
→ 勾选"请求/响应使用不同加解密"，用 requestorresponse 参数区分处理
```
