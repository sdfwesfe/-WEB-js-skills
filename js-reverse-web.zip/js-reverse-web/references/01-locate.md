# 01 精准定位

**适用条件：知道某个参数被加密，但不知道加密函数在哪个 JS 文件的哪一行。**
已找到加密函数 → 直接去 02-algorithms.md。

---

## 优先级判断

```
网站是 webpack 打包的？（Sources 看文件名有无 chunk/bundle/vendors）
├── 是 → 优先用 § 二 webpack 分析，比全局搜索快 10 倍
└── 否 → 直接用 § 一 关键词搜索

请求体是纯密文 blob（看不到任何参数名）？
├── 是 → § 1.1 接口路由定位
└── 否（参数名可见，值被加密）→ § 1.2 参数名搜索
```

---

## 一、四大定位法

### 1.1 接口路由定位（全加密 body）

```
Ctrl+Shift+F 全局搜索接口路径：
  /api/login   /api/sendSms   /api/register   /user/auth

→ 在接口调用处打断点
→ 触发请求（点击登录 / 发送验证码）
→ 断点命中后看右侧 Call Stack，从底向上追到加密函数入口
→ 在加密函数入口重新打断点，重放请求，看加密前原始数据
```

**技巧**：断点命中后先看 **Scope 面板**，所有当前作用域变量值都在里面，不用逐行 Step。

---

### 1.2 参数名搜索（半加密，参数名明文）

```
Ctrl+Shift+F 搜索参数名：
  password   mobile   phone   account   cardNo   idCard   amount

→ 找赋值语句：result.password = encrypt(raw)
  不要找声明语句：var password
→ 在赋值右侧的函数调用处打断点
→ 重放请求，Step Into 进入加密函数
→ 观察入参（明文）和返回值（密文）
```

---

### 1.3 加密关键词全局搜索

页面完全加载后（Network 无新请求），Ctrl+Shift+F：

```javascript
// 优先（命中率高）
CryptoJS        AES.encrypt     AES.decrypt
setPublicKey    publicKey =     JSEncrypt
MD5(            SHA256(         HMAC(
encrypt(        _encrypt        getSign
SM4             SM2             smCrypto

// 次优
aes_ecb         aes_cbc         RSA.encrypt
encodeURIComponent              btoa(

// 兜底
crypto          sign =          encode(
```

定位到文件 → Sources 找对应文件 → 在**函数定义处**打断点（不是调用处，定义处能捕获所有调用来源）。

---

### 1.4 调用栈追踪

```
Network → 点击目标请求 → Initiator 标签
→ 查看调用链，点击文件名跳转到 Sources
→ 打断点，重放请求
→ Call Stack 面板逐层向上追
→ 重点：参数在哪一层开始变成密文
```

---

## 二、webpack 站点分析

### 2.1 确认是否 webpack

```javascript
// F12 Console 输入，有返回值则是 webpack
window.__webpack_require__   // 通用
window.webpackChunk          // webpack 5
window.webpackJsonp          // webpack 4
```

### 2.2 直接调用任意模块

```javascript
// 获取所有已加载模块 ID
Object.keys(__webpack_require__.m)

// 直接调用目标模块（找到模块ID后）
const mod = __webpack_require__("./src/utils/crypto.js")
mod.encrypt("yourData")

// webpack 4：从 webpackJsonp 批量 dump 模块
var allModules = {}
var _orig = window.webpackJsonp.push.bind(window.webpackJsonp)
window.webpackJsonp.push = function(data) {
    Object.assign(allModules, data[1] || {})
    return _orig(data)
}
// 刷新页面，allModules 中有所有模块
```

### 2.3 Source Map 泄露利用

```bash
# 检查是否存在 source map（生产环境泄露时可直接看源码）
curl https://target.com/static/js/main.chunk.js.map
# 返回 JSON 而不是 404 → source map 存在

# 还原源码
npm install -g source-map-cli
source-map resolve main.chunk.js.map -o ./src-recovered/
```

Chrome DevTools 会自动加载 source map（Sources 面板左下角 `{}` 按钮）。

### 2.4 监听动态加载的 JS

```javascript
// 有些加密逻辑是懒加载的，监听动态创建的 script 标签
var _orig = document.createElement.bind(document)
document.createElement = function(tag) {
    var el = _orig(tag)
    if (tag.toLowerCase() === 'script') {
        Object.defineProperty(el, 'src', {
            set: function(val) {
                console.log('[Dynamic Script Loaded]', val)
                Object.getOwnPropertyDescriptor(
                    HTMLScriptElement.prototype, 'src'
                ).set.call(this, val)
            }
        })
    }
    return el
}
```

---

## 三、断点进阶

### 3.1 断点类型速查

| 类型 | 设置 | 场景 |
|------|------|------|
| 普通行断点 | 点击行号 | 已知目标行 |
| 条件断点 | 右键行号 → Add condition | 只在特定值时暂停 |
| Logpoint | 右键行号 → Add logpoint | 打日志不暂停 |
| XHR断点 | Sources → XHR/fetch Breakpoints | 拦截特定URL请求 |
| 事件监听断点 | Sources → Event Listener Breakpoints | 拦截click/submit |
| DOM断点 | Elements → 右键节点 → Break on | 监控DOM变化 |

### 3.2 条件断点高级写法

```javascript
// 只在特定参数值时暂停
mobile === "13800138000"

// 打日志但不暂停（条件永远为 false）
(console.log('明文:', data, 'key:', key, '密文:', result), false)

// 调用 N 次后才暂停
(window._cnt = (window._cnt||0)+1) >= 5
```

### 3.3 Logpoint 用法

```
右键行号 → Add logpoint
输入：plaintext={data} key={key} result={result}
// 大括号内直接写变量名，自动求值，不暂停执行
```

### 3.4 黑盒脚本（Blackbox）

调用栈中第三方库干扰分析时：右键 Call Stack 中的库文件 → **Blackbox script**

推荐黑盒：`jquery.min.js` / `crypto.js` / `lodash.js` / `axios.min.js`

### 3.5 异步调用追踪

```
Settings → Experiments → 勾选 "Async stack traces"
→ Promise / async/await 链的调用栈会完整显示

或：直接在加密函数的定义处打断点
    不管同步/异步调用，定义处必然触发
```

### 3.6 XHR 断点精确匹配

```
Sources → XHR/fetch Breakpoints → +
输入 URL 关键词：/api/login 或 sendSms 或 passport
断点在 XHR.send() 调用前命中
→ Call Stack 完整，向上追即可找到参数加密位置
```
