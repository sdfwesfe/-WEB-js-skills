# 05 风控参数专题

**适用条件：请求中存在 sign/signature/mac（签名）、fingerprint/fp/device_id（指纹）、uuid/trace_id（追踪）等参数需要还原。**

**处理顺序**：fingerprint → 其他参数 → sign（sign 依赖其他参数的值，必须最后算）

---

## 一、Sign 签名深度分析

### 1.1 定位签名生成函数

```
优先搜索：
  getSign   calcSign   generateSign   _sign   makeSign   buildSign

次优搜索：
  MD5(      HMAC(      SHA256(
  sortKeys  Object.keys(.*).sort
  sign =    signature =
```

### 1.2 分析参数排序规则

```javascript
// 规则一：字典序（最常见）
Object.keys(params).sort().forEach(k => str += k + '=' + params[k] + '&')

// 规则二：按参数在请求中出现的顺序（顺序固定，不能随意调换）

// 规则三：特定字段优先 + 其他字典序
['appid', 'timestamp', 'nonce'].forEach(k => str += k + '=' + params[k])

// 规则四：只签名部分字段（白名单）
var signFields = ['username', 'mobile', 'amount']
signFields.sort().forEach(k => str += k + '=' + params[k])
```

**断点调试方法**：
```javascript
// 在 getSign 函数内部，在 MD5/SHA256 调用前打 Logpoint：
'sign_str: ' + str + ' salt: ' + salt
// 对比打印出的 str，和手动拼接的结果，找到正确排序规则
```

### 1.3 盐值位置识别

```javascript
// hardcode（最常见）
var salt = "abcdef123456"

// 从 cookie 读取
var salt = document.cookie.match(/app_secret=([^;]+)/)[1]

// 从请求头读取（需配合 dataHeaders 参数分析）
var salt = request.headers['X-App-Secret']

// 动态生成
var salt = CryptoJS.MD5(appId + timestamp).toString().substring(0, 8)

// 识别方法：在 MD5/HMAC 调用处断点
// 打 Logpoint 打印完整的 sign_str，与抓包里的 sign 逆推
```

### 1.4 时间窗口问题

```python
import time

ts_sec = int(time.time())           # 秒级时间戳
ts_ms  = int(time.time() * 1000)    # 毫秒级时间戳

# 重放失败时：检查本地时间和服务器时间是否一致
# 从响应头 Date 字段获取服务器时间：
import email.utils
server_time = email.utils.parsedate_to_datetime(
    response.headers.get('Date', '')
)
```

### 1.5 嵌套签名（伪循环依赖）

看起来循环依赖，实际上是有固定计算顺序。

```
分析方法：
1. 在 XHR.send() 处打断点
2. 查看 body 中每个参数的赋值时序（Scope 面板）
3. 向上追每个参数的最后一次赋值时刻
4. 确定计算顺序：通常是
   fingerprint → token → encrypt(data) → sign
```

### 1.6 完整 Python 复现模板

```python
import hashlib, hmac, time, json

def generate_sign(params: dict, salt: str,
                  algorithm: str = 'md5',
                  sort_keys: bool = True,
                  salt_position: str = 'append') -> str:
    """
    通用签名生成
    algorithm: 'md5' / 'sha256' / 'hmac_sha256' / 'hmac_md5'
    salt_position: 'prepend' / 'append' / 'both'
    """
    keys = sorted(params.keys()) if sort_keys else list(params.keys())
    parts = [f"{k}={params[k]}" for k in keys if str(params[k]) != '']
    param_str = '&'.join(parts)

    if salt_position == 'prepend':
        sign_str = salt + param_str
    elif salt_position == 'append':
        sign_str = param_str + salt
    else:  # both
        sign_str = salt + param_str + salt

    if algorithm == 'md5':
        return hashlib.md5(sign_str.encode()).hexdigest()
    elif algorithm == 'sha256':
        return hashlib.sha256(sign_str.encode()).hexdigest()
    elif algorithm == 'hmac_sha256':
        return hmac.new(salt.encode(), sign_str.encode(), hashlib.sha256).hexdigest()
    elif algorithm == 'hmac_md5':
        return hmac.new(salt.encode(), sign_str.encode(), hashlib.md5).hexdigest()

# 使用
params = {
    'mobile': '13800138000',
    'timestamp': str(int(time.time())),
    'nonce': 'abc123',
    'appid': 'com.example.app',
}
sign = generate_sign(params, salt='your_salt_here', algorithm='md5')
params['sign'] = sign
```

---

## 二、Fingerprint 设备指纹

### 2.1 各类指纹生成原理

**Canvas 指纹**
```javascript
// 不同设备/浏览器渲染文字方式略有差异
var canvas = document.createElement('canvas')
var ctx = canvas.getContext('2d')
ctx.textBaseline = 'top'
ctx.font = '14px Arial'
ctx.fillText('BrowserLeaks,com <canvas> 1.0', 2, 2)
var fingerprint = canvas.toDataURL()  // hash 这个值
```

**WebGL 指纹**
```javascript
var gl = canvas.getContext('webgl')
var dbg = gl.getExtension('WEBGL_debug_renderer_info')
var vendor = gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL)
var renderer = gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL)
// vendor + renderer 组合为 WebGL 指纹
```

**AudioContext 指纹**
```javascript
var ctx = new AudioContext()
var oscillator = ctx.createOscillator()
var analyser = ctx.createAnalyser()
var gain = ctx.createGain()
gain.gain.value = 0  // 静音，不影响用户
oscillator.connect(analyser)
analyser.connect(ctx.destination)
oscillator.start(0)
// 采样 analyser 的 float 数组，hash 值即指纹
```

### 2.2 FingerprintJS 识别与定位

```
代码特征：
  npm 包名：@fingerprintjs/fingerprintjs 或 fingerprintjs2
  调用：FingerprintJS.load() / Fingerprint2.get()
  结果字段：visitorId（v3）/ result（v2）

定位方法：
  全局搜索：FingerprintJS  visitorId  Fingerprint2  fpPromise
  在 .then(result => ...) 处打断点
  断点命中后 Scope 面板直接看 visitorId 值
```

### 2.3 授权测试中验证指纹有效性

```python
import requests

# 测试1：伪造随机 fingerprint
resp = requests.post(url, data={**payload, 'fingerprint': 'fake_fp_xyz'})
# → 正常响应：fingerprint 未校验，可随意填写
# → 报错响应：需要正确生成

# 测试2：重复使用同一个 fingerprint
real_fp = '从正常请求中提取的值'
resp1 = requests.post(url, data={**payload, 'fingerprint': real_fp})
resp2 = requests.post(url, data={**payload, 'fingerprint': real_fp})
# 两次都成功 → 无唯一性校验
# 第二次失败 → 有唯一性校验，需要每次生成
```

### 2.4 jsrpc 获取真实指纹

```javascript
// 在目标页面 Console 注入 jsrpc 客户端后：
Hlclient.regAction("getFingerprint", function(resolve) {
    // FingerprintJS v3
    if (typeof FingerprintJS !== 'undefined') {
        FingerprintJS.load().then(fp => fp.get()).then(r => resolve(r.visitorId))
        return
    }
    // 页面内置指纹函数
    if (typeof util !== 'undefined' && util.getH5fingerprint) {
        resolve(util.getH5fingerprint(location.href))
        return
    }
    // 页面已计算好的指纹（很多页面加载时就算好存在全局变量里）
    resolve(window.__fingerprint || window._fp || window.__fp || '')
})
```

---

## 三、UUID / Trace-ID 分析

### 3.1 规律分析

```
步骤：连续抓取 10 次以上，记录所有 uuid/trace_id 值

分析：
  - 是否包含时间戳（将数值部分转为时间戳验证）
  - 长度是否固定（32位十六进制 = UUID格式）
  - 刷新页面后是否变化 vs 每次请求都变化
  - 是否有递增规律

定位生成函数：
  全局搜索：uuid  generateUUID  getTraceId  getRequestId  Math.random()
```

### 3.2 验证服务端是否校验

```python
# 测试1：伪造
resp = requests.post(url, headers={'X-Trace-Id': 'fake-uuid-abcdef'}, data=payload)
print('伪造:', resp.status_code)

# 测试2：重复使用
real_id = '真实请求中的值'
r1 = requests.post(url, headers={'X-Trace-Id': real_id}, data=payload)
r2 = requests.post(url, headers={'X-Trace-Id': real_id}, data=payload)
print('重复第一次:', r1.status_code, '第二次:', r2.status_code)
# 两次都成功 → 无校验，可固定值或随机生成
```

### 3.3 Python 生成常见格式

```python
import uuid, time, random, string

def gen_uuid_v4() -> str:
    return str(uuid.uuid4()).replace('-', '')

def gen_trace_id() -> str:
    ts = int(time.time() * 1000)
    rand = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
    return f"{ts}{rand}"

def gen_nanoid(size: int = 21) -> str:
    chars = 'useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict'
    return ''.join(random.choices(chars, k=size))
```
