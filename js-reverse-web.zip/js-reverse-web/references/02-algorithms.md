# 02 算法识别与还原

**适用条件：已找到加密函数，需要识别算法、提取密钥、写复现代码。**
代码混淆看不懂 → 先去 03-obfuscation.md。

---

## 一、密文特征速查表

| 密文特征 | 算法推断 | 验证搜索词 |
|----------|----------|-----------|
| 32位十六进制 | MD5 | `MD5(` |
| 40位十六进制 | SHA1 | `SHA1(` |
| 64位十六进制 | SHA256 / HMAC-SHA256 | `SHA256(` `HMAC(` |
| Base64，16字节块整数倍 | AES / SM4 | `AES.encrypt` `SM4` |
| Base64解码后128字节 | RSA-1024 | `setPublicKey` |
| Base64解码后256字节 | RSA-2048 | `setPublicKey` |
| `U2FsdGVk` 前缀（Base64） | CryptoJS AES openssl格式 | `CryptoJS.AES` |
| 含 `-` 和 `_` 无 `+` `/` | URL-safe Base64变体 | 先替换再解码 |
| 相同明文两次相同 | ECB模式 or Hash | 无IV |
| 相同明文两次不同 | CBC/RSA/含盐 | 含随机IV或填充 |
| 密文以 `04` 开头（hex） | SM2 未压缩点 | `sm2.doEncrypt` |

---

## 二、AES 全系

### 2.1 四种模式识别

| 模式 | 特征 | 断点搜索 |
|------|------|---------|
| ECB | 同明文=同密文，无IV | `mode.ECB` |
| CBC | 同明文=不同密文，有IV | `mode.CBC` `iv` |
| CTR | 密文长度=明文长度（无padding） | `mode.CTR` |
| GCM | 末尾有16字节认证tag | `mode.GCM` `tag` |

### 2.2 密钥/IV 常见藏法

```
1. Hardcode（最常见）：16/24/32 字节字符串常量
2. HTTP 响应中返回：抓 /init /getConfig /getPublicKey 接口
3. Cookie / localStorage：搜 document.cookie / localStorage.getItem
4. DOM 隐藏：搜 getAttribute('data-key') / dataset.secret
5. 动态计算：在 CryptoJS.AES.encrypt 入口断点，观察 key 变量每次的值
```

### 2.3 Python 复现

```python
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import base64, time

# AES-ECB
def aes_ecb_enc(plaintext: str, key: str) -> str:
    c = AES.new(key.encode(), AES.MODE_ECB)
    return base64.b64encode(c.encrypt(pad(plaintext.encode(), 16))).decode()

def aes_ecb_dec(ciphertext: str, key: str) -> str:
    c = AES.new(key.encode(), AES.MODE_ECB)
    return unpad(c.decrypt(base64.b64decode(ciphertext)), 16).decode()

# AES-CBC
def aes_cbc_enc(plaintext: str, key: str, iv: str) -> str:
    c = AES.new(key.encode(), AES.MODE_CBC, iv.encode())
    return base64.b64encode(c.encrypt(pad(plaintext.encode(), 16))).decode()

def aes_cbc_dec(ciphertext: str, key: str, iv: str) -> str:
    c = AES.new(key.encode(), AES.MODE_CBC, iv.encode())
    return unpad(c.decrypt(base64.b64decode(ciphertext)), 16).decode()

# AES-GCM
def aes_gcm_enc(plaintext: str, key: bytes, nonce: bytes):
    c = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ct, tag = c.encrypt_and_digest(plaintext.encode())
    return base64.b64encode(ct).decode(), base64.b64encode(tag).decode()

# 时间戳前缀场景（明文 = timestamp + password）
def aes_ecb_with_ts(plaintext: str, key: str) -> dict:
    ts = int(time.time() * 1000)
    return {"data": aes_ecb_enc(str(ts) + plaintext, key), "time": ts}

# URL-safe Base64 变体（/ → _ ，+ → -）
def aes_ecb_urlsafe(plaintext: str, key: str) -> str:
    return aes_ecb_enc(plaintext, key).replace('/', '_').replace('+', '-')

def aes_ecb_urlsafe_dec(ciphertext: str, key: str) -> str:
    return aes_ecb_dec(ciphertext.replace('_', '/').replace('-', '+'), key)
```

### 2.4 浏览器控制台验证

```javascript
// 解密验证（确认 key 正确）
CryptoJS.AES.decrypt(
    "你抓到的密文",
    CryptoJS.enc.Utf8.parse("你找到的key"),
    { mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7 }
).toString(CryptoJS.enc.Utf8)
// 能解出明文 → key 正确

// 加密验证
CryptoJS.AES.encrypt(
    CryptoJS.enc.Utf8.parse("yourPlaintext"),
    CryptoJS.enc.Utf8.parse("yourKey123456789"),
    { mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7 }
).toString()
```

---

## 三、RSA 全系

### 3.1 公钥格式识别

```
PKCS8（最常见，以 MIGf 或 MIIBIj 开头）：
  MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQ...

PKCS1（以 MIIB 开头，无 MA0GCSqG 特征串）：
  MIIBCgKCAQEA...

裸模数+指数（代码里直接出现两个大整数）：
  this.n = "00b3510a..."  // modulus（模数）
  this.e = 65537          // exponent（指数，通常固定）
```

### 3.2 加密模式识别

```
相同明文每次密文不同 → PKCS1 v1.5（含随机填充，正常现象）
代码含 OAEP / sha1 / sha256 参数 → RSA-OAEP
使用 JSEncrypt 库 → 默认 PKCS1 v1.5
```

### 3.3 Python 复现

```python
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5, PKCS1_OAEP
import base64

def rsa_pkcs1_enc(plaintext: str, pub_key_b64: str) -> str:
    pem = f"-----BEGIN PUBLIC KEY-----\n{pub_key_b64}\n-----END PUBLIC KEY-----"
    cipher = PKCS1_v1_5.new(RSA.import_key(pem))
    return base64.b64encode(cipher.encrypt(plaintext.encode())).decode()

def rsa_oaep_enc(plaintext: str, pub_key_b64: str) -> str:
    from Crypto.Hash import SHA1
    pem = f"-----BEGIN PUBLIC KEY-----\n{pub_key_b64}\n-----END PUBLIC KEY-----"
    cipher = PKCS1_OAEP.new(RSA.import_key(pem), hashAlgo=SHA1)
    return base64.b64encode(cipher.encrypt(plaintext.encode())).decode()

# 裸模数+指数格式
def rsa_from_components(plaintext: str, n_hex: str, e: int = 65537) -> str:
    key = RSA.construct((int(n_hex, 16), e))
    cipher = PKCS1_v1_5.new(key)
    return base64.b64encode(cipher.encrypt(plaintext.encode())).decode()
```

---

## 四、国密 SM2 / SM4

国内金融、政务、医疗系统大量使用，遇到国密特征先搜 `sm-crypto` / `gmssl` / `SM4` / `SM2`。

### 4.1 SM4（对称，类似 AES）

```python
# pip install gmssl
from gmssl.sm4 import CryptSM4, SM4_ENCRYPT, SM4_DECRYPT
import base64

def sm4_ecb_enc(plaintext: str, key: str) -> str:
    crypt = CryptSM4()
    crypt.set_key(key.encode(), SM4_ENCRYPT)
    data = plaintext.encode()
    pad_len = 16 - len(data) % 16
    data += bytes([pad_len] * pad_len)
    return base64.b64encode(crypt.crypt_ecb(data)).decode()

def sm4_cbc_enc(plaintext: str, key: str, iv: str) -> str:
    crypt = CryptSM4()
    crypt.set_key(key.encode(), SM4_ENCRYPT)
    data = plaintext.encode()
    pad_len = 16 - len(data) % 16
    data += bytes([pad_len] * pad_len)
    return base64.b64encode(crypt.crypt_cbc(iv.encode(), data)).decode()
```

### 4.2 SM2（非对称，类似 RSA）

```python
# pip install gmssl
from gmssl import sm2

def sm2_enc(plaintext: str, public_key: str) -> str:
    # public_key：64字节十六进制（去掉 "04" 前缀后的 128 字符）
    crypt = sm2.CryptSM2(public_key=public_key, private_key="")
    return crypt.encrypt(plaintext.encode()).hex()
```

---

## 五、Hash 与签名

### 5.1 加盐方式识别

```javascript
// 在控制台测试哪种拼接方式能得到和抓包一致的 hash
CryptoJS.MD5("salt" + "plaintext").toString()    // 前置盐
CryptoJS.MD5("plaintext" + "salt").toString()    // 后置盐
CryptoJS.MD5("plaintext").toString() + "salt"    // hash 后拼接（少见）
CryptoJS.HmacMD5("plaintext", "secret").toString() // HMAC
```

### 5.2 Python 复现

```python
import hashlib, hmac

def md5(text: str) -> str:
    return hashlib.md5(text.encode()).hexdigest()

def sha256(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()

def hmac_sha256(text: str, secret: str) -> str:
    return hmac.new(secret.encode(), text.encode(), hashlib.sha256).hexdigest()

def double_md5(text: str) -> str:
    return md5(md5(text))
```

---

## 六、自定义加密识别

### 6.1 XOR 加密

**识别**：大量 `^` 运算，密文长度 = 明文长度。

```python
def xor_enc(plaintext: str, key: str) -> str:
    return ''.join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(plaintext))

def xor_enc_hex(plaintext: str, key: str) -> str:
    return bytes(b ^ key.encode()[i % len(key)] for i, b in enumerate(plaintext.encode())).hex()
```

### 6.2 自定义 Base64 字符表

**识别**：密文字符集不是标准的 `A-Za-z0-9+/`，但长度符合 Base64 规律。

```python
import base64

def custom_b64_dec(ciphertext: str, custom_table: str) -> bytes:
    std = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    trans = str.maketrans(custom_table, std)
    return base64.b64decode(ciphertext.translate(trans) + "==")
```

### 6.3 分析方法：选择相近明文

完全不知道算法时，用输入差异对比推断：

```
提交 "aaaaaaaaaaaaaaaa"（16个a）→ 记录密文 C1
提交 "baaaaaaaaaaaaaaa"（只改第1位）→ 记录密文 C2

只有第1个字节不同 → 可能是流加密或 ECB
前16字节全不同，后面相同 → ECB 模式
整体都不同 → CBC 或更复杂算法

继续改变不同位置，观察密文变化规律，推断算法结构
```

---

## 七、多层加密剥离

### 7.1 识别方法

```
在最终 XHR.send() 前打断点，观察 body 值
→ 向上追，在每个赋值语句处打断点
→ 记录每次赋值前后的值变化
→ 画出数据流图
```

### 7.2 数据流图示例

```
raw: "QWas1234."
  ↓ 拼接 Date.now()
"1736695076115QWas1234."
  ↓ UTF8 encode
bytes
  ↓ AES-ECB (key="-imagic-password")
encrypted_bytes
  ↓ Base64 encode
"SGVs...bG8="
  ↓ 字符替换 / → _ , + → -
password = "SGVs...bG8="
  + time = 1736695076115  （单独参数）
```

### 7.3 还原必须严格反向

```python
# 加密顺序：timestamp拼接 → AES-ECB → Base64 → 字符替换
# 解密顺序：字符替换还原 → Base64解码 → AES-ECB解密 → 去掉时间戳前缀

def full_decrypt(ciphertext: str, key: str) -> dict:
    fixed = ciphertext.replace('_', '/').replace('-', '+')  # 还原字符替换
    plaintext = aes_ecb_dec(fixed, key)
    ts = plaintext[:13]       # 前13位是毫秒时间戳
    password = plaintext[13:] # 剩余是原始密码
    return {"timestamp": ts, "password": password}
```
