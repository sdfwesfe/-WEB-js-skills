# 03 混淆对抗

**适用条件：JS 代码混淆，变量名乱码 / 巨大字符串数组 / 控制流平坦化 / VM保护。**
核心原则：**不要试图完全读懂混淆代码，用动态执行弥补静态分析的不足。**

---

## 一、混淆程度快速识别

```
打开目标 JS 文件，看以下特征：

✦ 轻度：变量名是 _0x1a2b，但逻辑结构清晰，有 if/else 可追
  → 断点追踪即可，不需要反混淆工具

✦ 中度：文件头有几百个元素的字符串数组 + while/switch 控制流
  → 字符串数组还原 + synchrony

✦ OB 重度（javascript-obfuscator 全量）：
  IIFE + 巨大字符串数组 + 洗牌函数 + 大量 parseInt
  几乎每个字符串都是 _0x1234(0x1a) 形式
  → synchrony 工具 / babel AST

✦ VM 保护（极重度）：
  含 pc / stack / registers / opcode / bytecode 关键词
  主逻辑是 while(true) { switch(opcode){...} }
  → 不要尝试静态分析，直接 Hook I/O
```

---

## 二、轻度混淆处理

### 2.1 读变量值，不读变量名

```
断点命中后：
→ 悬停变量名，浏览器 tooltip 显示实际值
→ Scope 面板展开当前作用域，批量查看所有变量
→ Console 直接输入变量名查看值
```

### 2.2 常见混淆模式快速还原

```javascript
// 十六进制数字
_0x1a === 26     // Console 直接验证

// 布尔值
![]  === false
!![] === true
!{}  === false

// 十六进制字符串
'\x68\x65\x6c\x6c\x6f'  // Console 输入得到 "hello"

// void 0
void 0 === undefined
```

### 2.3 批量打印当前作用域变量

```javascript
// Sources → Snippets → New → 粘贴执行
Object.entries(window)
  .filter(([k]) => k.startsWith('_0x'))
  .forEach(([k,v]) => console.log(
    k, '=', typeof v,
    typeof v === 'function' ? v.toString().slice(0, 80) : v
  ))
```

---

## 三、中度混淆处理

### 3.1 字符串数组批量还原

找到解码函数（文件顶部，接受索引参数），在 Console 批量调用：

```javascript
// 假设解码函数名为 _0x5e3f
var strMap = {}
for (var i = 0; i < 500; i++) {
    try {
        var v = _0x5e3f(i)
        if (v !== undefined) strMap[i] = v
    } catch(e) {}
}
console.table(strMap)
// 复制映射表，手动替换代码中的索引调用
```

### 3.2 控制流平坦化应对

遇到 `while(true) { switch(_seq[i++]) {...} }` 时：

```
不要试图还原顺序，直接找结果：

方法一：在每个 case 的 return / resolve 处打断点
        执行后在 Scope 面板直接看最终结果

方法二：在函数出口（return 语句处）打断点
        不管内部多复杂，最终必经 return

方法三：Console 直接调用整个函数，看输入输出
        _0x2abc("yourData")
```

### 3.3 eval 动态执行追踪

```javascript
// 注入到 Console 或 Tampermonkey，Hook eval
var _origEval = window.eval
window.eval = function(code) {
    console.log('[eval] length:', code.length, '\n', code.slice(0, 300))
    debugger  // 暂停，可检查完整代码
    return _origEval.call(this, code)
}

// 同理 Hook Function 构造器
var _origFn = window.Function
window.Function = function() {
    var args = Array.from(arguments)
    var body = args[args.length - 1] || ''
    console.log('[Function constructor]', String(body).slice(0, 300))
    return _origFn.apply(this, arguments)
}
```

---

## 四、OB 混淆完整处理流程

### 4.1 synchrony 工具（首选）

```bash
npm install -g @javascript-obfuscator/synchrony

# 基本还原
synchrony deobfuscate obfuscated.js -o clean.js

# 指定转换（失败时逐步排查）
synchrony deobfuscate obfuscated.js \
    --transforms stringArray \
    --transforms controlFlowFlattening \
    -o clean.js

# 验证还原结果是否可运行
node -e "require('./clean.js')"

# 验证还原前后加密结果一致
# 在浏览器 Console 和 Node.js 中用相同输入调用加密函数，对比输出
```

### 4.2 babel AST 手动处理（synchrony 失败时）

```bash
npm install @babel/core @babel/parser @babel/traverse @babel/generator @babel/types
```

```javascript
const babel = require('@babel/core')
const traverse = require('@babel/traverse').default
const generator = require('@babel/generator').default
const t = require('@babel/types')
const fs = require('fs')
const vm = require('vm')

const code = fs.readFileSync('obfuscated.js', 'utf8')
const ast = babel.parseSync(code, { sourceType: 'script' })

// ── Visitor 1：十六进制数字还原 ───────────────────────
traverse(ast, {
    NumericLiteral(path) {
        path.node.extra = { raw: String(path.node.value) }
    }
})

// ── Visitor 2：布尔值还原 ─────────────────────────────
traverse(ast, {
    UnaryExpression(path) {
        if (path.node.operator === '!' &&
            t.isArrayExpression(path.node.argument) &&
            path.node.argument.elements.length === 0) {
            path.replaceWith(t.booleanLiteral(false))
        }
    }
})

// ── Visitor 3：字符串数组内联（需先执行代码拿到解码函数）──
const sandbox = {}
vm.runInNewContext(code, sandbox)
const decodeFn = sandbox['_0x5e3f'] // 替换为实际函数名

traverse(ast, {
    CallExpression(path) {
        const callee = path.node.callee
        if (t.isIdentifier(callee) && callee.name === '_0x5e3f') {
            const arg = path.node.arguments[0]
            if (t.isNumericLiteral(arg)) {
                try {
                    const val = decodeFn(arg.value)
                    if (typeof val === 'string') {
                        path.replaceWith(t.stringLiteral(val))
                    }
                } catch (e) {}
            }
        }
    }
})

// ── Visitor 4：死代码删除 ─────────────────────────────
traverse(ast, {
    IfStatement(path) {
        const test = path.node.test
        if (t.isBooleanLiteral(test)) {
            if (test.value === false) path.remove()
            else path.replaceWith(path.node.consequent)
        }
    }
})

fs.writeFileSync('clean.js', generator(ast, { compact: false }).code)
```

---

## 五、VM 保护处理

**原则：不要逆向 VM 本身，成本极高。全部用动态 Hook 方案。**

### 5.1 识别 VM 保护

```javascript
// 代码中同时出现多个以下关键词 → VM 保护
pc          // 程序计数器
stack       // 操作数栈
registers   // 寄存器
opcode      // 操作码
bytecode    // 字节码
```

### 5.2 Hook 底层加密 API（最有效）

```javascript
// VM 最终必须调用真实 API，在这里拦截
// Hook CryptoJS
if (typeof CryptoJS !== 'undefined') {
    const _orig = CryptoJS.AES.encrypt
    CryptoJS.AES.encrypt = function(data, key, cfg) {
        console.log('[CryptoJS.AES.encrypt]',
            '\n  data:', data.toString ? data.toString() : data,
            '\n  key:', key.toString ? key.toString() : key,
            '\n  mode:', cfg && cfg.mode
        )
        const r = _orig.apply(this, arguments)
        console.log('  result:', r.toString())
        return r
    }
}

// Hook WebCrypto（现代浏览器加密API）
const _origEncrypt = window.crypto.subtle.encrypt.bind(window.crypto.subtle)
window.crypto.subtle.encrypt = async function(algorithm, key, data) {
    console.log('[WebCrypto.encrypt] algorithm:', JSON.stringify(algorithm))
    const result = await _origEncrypt(algorithm, key, data)
    console.log('[WebCrypto.encrypt] result bytes:', result.byteLength)
    return result
}
```

### 5.3 VM 指令追踪（辅助定位）

在 switch(opcode) 主循环处打 Logpoint，不暂停只打印：

```javascript
// Logpoint 内容（不暂停执行）：
'op:' + opcode + ' stack:' + JSON.stringify(stack.slice(-2))
// 从日志中找到加密相关的指令序列
```

### 5.4 兜底：jsrpc

VM 代码在浏览器中能正常运行，直接用 jsrpc 把浏览器变成加密服务器，跳过 VM 分析。详见 06-execution.md § 三。
