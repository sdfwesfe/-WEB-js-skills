---
name: js-reverse-web
description: >
  Web前端JS逆向分析专项技能，面向授权渗透测试与安全研究场景。

  【立即触发的场景】
  - 抓包发现请求体或参数值是密文/乱码，需要还原加密逻辑
  - 需要逆向前端JS加密算法（AES / RSA / SM2 / SM4 / 自定义加密）
  - 遇到JS混淆代码（OB混淆 / 控制流平坦化 / VM字节码保护）
  - 需要分析还原 sign签名 / fingerprint设备指纹 / token 生成逻辑
  - 遇到反调试手段（无限debugger / 时间检测 / DevTools检测 / 焦点检测）
  - 需要配合 Burp autoDecoder 插件实现自动加解密（Flask接口 / 接口规范 / 联调）
  - 需要搭建 jsrpc / Puppeteer / Node.js补环境 执行浏览器端加密逻辑
  - 需要对加密数据包做 sqlmap / Intruder / Repeater 自动化测试

  【不触发的场景】
  - 只是写普通的AES/RSA加解密代码（不涉及逆向）
  - 询问加密算法的理论或数学原理
  - 服务端加密开发
  - 普通Burp抓包，没有加密参数还原需求
---

# Web JS 逆向分析

面向**授权渗透测试与安全研究**。拿到目标后先看快速路由，直接跳对应文档，不要全部加载。

---

## 快速路由

| 当前问题 | 读这个文档 |
|----------|-----------|
| 找不到加密函数在哪里 | [01-locate.md](references/01-locate.md) |
| 找到了，要识别算法、提取密钥、写复现代码 | [02-algorithms.md](references/02-algorithms.md) |
| 代码混淆，变量名乱码 / 字符串数组 / 读不懂 | [03-obfuscation.md](references/03-obfuscation.md) |
| 断点被干扰：无限debugger / 时间检测 / DevTools检测 | [04-anti-debug.md](references/04-anti-debug.md) |
| 请求有 sign / fingerprint / uuid 需要还原 | [05-risk-params.md](references/05-risk-params.md) |
| 选执行方案 / 接 autoDecoder / jsrpc / Puppeteer | [06-execution.md](references/06-execution.md) |

---

## 不确定入手点？走这里

```
第一步：看请求体
├── 整个 body 是密文 blob          → 01-locate.md § 接口路由定位
├── 参数名明文，参数值加密           → 01-locate.md § 参数名搜索
└── 有 sign / fingerprint 附加参数  → 05-risk-params.md

第二步：判断密文类型（相同明文提交两次）
├── 两次密文相同    → AES-ECB / SM4-ECB，找固定 key
├── 两次密文不同    → RSA / AES-CBC / 含随机盐
├── 32位十六进制    → MD5
├── 64位十六进制    → SHA256 / HMAC
├── Base64解码128B  → RSA-1024
├── Base64解码256B  → RSA-2048
└── U2FsdGVk 前缀  → CryptoJS AES openssl 格式

第三步：判断代码可读性（Ctrl+Shift+F 搜 "CryptoJS" / "AES" / "encrypt"）
├── 能搜到明文关键词   → 02-algorithms.md
├── 变量名 _0x1a2b     → 03-obfuscation.md § 轻度
├── 巨大字符串数组      → 03-obfuscation.md § OB混淆
└── pc/stack/opcode    → 03-obfuscation.md § VM保护

第四步：选执行方案
├── 能提取密钥和算法       → Python/Node直接复现（02-algorithms.md有模板）
├── 依赖浏览器 API         → jsrpc（06-execution.md § 三）
├── 需要完整页面           → Puppeteer（06-execution.md § 四）
└── Burp 联动自动加解密    → autoDecoder（06-execution.md § 五）
```

---

## 工具速查

| 用途 | 工具 |
|------|------|
| 抓包/改包/重放 | Burp Suite / mitmproxy |
| 断点调试 | Chrome DevTools |
| 代码格式化 | js-beautify / DevTools 内置 {} |
| OB反混淆 | synchrony / de4js |
| AST分析 | ast-explorer.net / babel |
| 页面注入脚本 | Tampermonkey |
| 传输层替换JS | mitmproxy addon |
| 浏览器作加密服务 | jsrpc |
| 完整浏览器自动化 | Puppeteer / Playwright |
| Burp自动加解密 | autoDecoder + Flask接口 |
| 算法复现 | Python pycryptodome / gmssl |
